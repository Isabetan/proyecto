const carrusel = document.querySelector(".carrusel");
const slides = document.querySelectorAll(".slide");

let index = 0;

function nextSlide() {
    slides[index].style.transform = "translateX(-100%)";
    index = (index + 1) % slides.length;
    slides[index].style.transform = "translateX(0)";
}

setInterval(nextSlide, 2000); // Cambia la imagen cada 2 segundos